const fetch = require("node-fetch");
const url = "https://yyh7a8n6ll.execute-api.us-east-1.amazonaws.com/prod/questionAPI";

module.exports = {
     async getLocation() {
        try {
            console.log("******Inside Api Call******");
            const response = await fetch(url);
            return new Promise(async function (resolve, reject) {
                const json = await response.json();
                console.log(" Api response from node-fetch js "+ JSON.stringify(json));
                resolve(json);
            });
        } catch (error) {
            console.error(" Error while fetching question from node-fetch js file "+ error);
        }
    }
};